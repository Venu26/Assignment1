#!/bin/bash
while read -r line
do
let x=${#line}
if test $x -le 4
	then echo $line >> q1_output.txt 
	continue	
else
echo -n ${line:0:4} >> q1_output.txt
fi
for((i=4;i < $x;i++))
do
echo -n "#" >> q1_output.txt
done
echo >> q1_output.txt
done < "$1"

