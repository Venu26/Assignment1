#!/bin/bash
while read l
do
if test "$l" == ""
then break
else
sed -i "s/\b$l\b//g" "$1" 
sed -i 's/ \{2,\}/ /g' "$1"
fi
done < "$2"
#let a=`(cat input.txt | wc -w)` 
#echo $a
#let b=`(grep -o "\<$3\>" input.txt | wc -l)` 
#echo $b
#tf=`(echo "$b / $a" | bc -l)`
#echo $tf
var1="$3"
declare -i count=0
while read l
do
if test "$l" == ""
then break
else
for var2 in $l
do
if test "$var2" == "$var1"
then
((count++))
fi
done
fi
let length=0
#let length=`(echo "$l" | wc -w)`
for word in $l
do
	if [ $word != ',' ] && [ $word != '.' ] && [ $word != '?' ] && [ $word != '!' ] && [ $word != ';' ]
	then 
	
		((length++))	
	fi	
done
#let punc=`(echo "$l" | grep -o '[[:punct:]]' | wc -w)`
#let len=`(echo "$length - $punc" | bc)`
echo -n -e "$l, " >> Output.txt 
echo "$count / $length" | bc -l >> Output.txt
let count=0
done < "$1"
