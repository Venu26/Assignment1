#!/bin/bash
declare  day
declare  month
declare  year
declare var1
declare name
while read -r line
do
let x=${#line}
day=${line:$(($x-10)):2}
month=${line:$(($x-7)):2}
year=${line:$(($x-4)):4}
name=${line:0:$(($x-10))}
let m=`(date +"%m")`
let y=`(date +"%Y")`
let d=`(date +"%d")`
echo -n "$name" >> q2_output.txt
declare -i AgeY=`(echo $y - $year | bc)` 
declare -i AgeM=`(echo $m - $month | bc)`
declare -i AgeD=`(echo $d - $day | bc)`
if test $AgeM -gt 0
then
echo "$AgeY" >> q2_output.txt
fi
if test $AgeM = 0
then 
if test $AgeD -ge 0
then
echo "$AgeY" >> q2_output.txt
else
expr $AgeY - 1 >> q2_output.txt
fi
fi
if test $AgeM -lt 0
then expr $AgeY - 1 >> q2_output.txt
fi 
done < "$1" 
