#!/bin/bash

declare -a array1
declare -a array2
declare -a array3
declare -a array4

declare -i count1=-1 count2=-1 count3=-1 count4=-1
while read l
do
for var1 in $l
do
		if test "${var1:0:1}" == "s"
		then
		{
			if test "${var1:1:1}" != "a"
			then
				{
					((count1++))
					array1[$count1]="$var1"
				}
			fi
		}
		fi
		if test "${var1:0:1}" == "w"
		 then
		 if test "${var1:1:1}" == "h"
		 then
			     {
				((count2++))
		   		array2[$count2]="$var1"
			     }
     		fi
		fi
		if test "${var1:0:1}" == "t"
		then
		if test "${var1:1:1}" == "h"
		then	
			     {
		     		((count3++))
	   			array3[$count3]="$var1"
			     }
		fi
		fi
		if test "${var1:0:1}" == "a"
		then
			 if test "${var1:1:1}" != "n"
		  	 then				
				{
		       			((count4++))
					array4[$count4]="$var1"
				}
			fi
		fi

done
done < "$1"
echo Words - start with ‘s’ and is not follow by ‘a’ 
echo ${array1[*]} 
echo Words starts with ‘w’ and is followed by ‘h’
echo ${array2[*]}
echo Words starts with ‘t’ and is followed by ‘h’
echo ${array3[*]}
echo Words starts with ‘a’ and is not followed by ‘n’
echo ${array4[*]}




