#!/bin/bash
declare -i x
declare -i y
declare -a array
declare -a array2
declare -i count=0
declare -i count1=0
l="$1"
if test "$l" = ""
then l="$PWD"
fi
p=`(find "$l")`
#for file in "$l"/*
#do
#if [ -d "${file}" ] ; then

#	array[$count]="$file"
#	((count++))
#fi
#if [ -f "${file}" ] ; then
#	array1[$count1]="$file"
#	((count1++))
#fi
#done
#echo $p
for var1 in $p
do
#echo "$var1"
if [ -d "$var1" ] ; then
	array[$count]="$var1"
	((count++))
fi
if [ -f "$var1" ] ; then 
	array1[$count1]="$var1"
	((count1++))
fi
done

#echo ${array[*]}
#echo ${array1[*]}
#for((i=0;i<count;i++))
#do
#for((j=0;j<count-1;j++))
#do
#{
#	x=`(find "${array[$j]}" -type f | wc -l)`
#	y=`(find "${array[$(($j+1))]}" -type f | wc -l)`
#	if test $x -lt $y
#	then
#		var1="${array[$(($j+1))]}"
#		array[$(($j+1))]="${array[$j]}"
#		array[$j]="$var1"
#	fi
#}
#done
#let j=0
#done
#for((i=0;i<count1;i++))
#do
#for((j=0;j<count1-1;j++))
#do
#x=`(find "${array1[$j]}" -printf "%s")`
#y=`(find "${array1[$(($j+1))]}" -printf "%s")`
#if test $x -lt $y
#then
#	var1="${array1[$(($j+1))]}"
#	array1[$(($j+1))]="${array1[$j]}"
#	array1[$j]="$var1"
#fi
#done
#let j=0
#done
for ((i=1;i<count;i++))
do
	echo $(basename ${array[$i]}) `(find "${array[$i]}" -type f | wc -l)` "file(s)" >> venu.txt
	clear
done
echo Directories: >> answer.txt
sort -k 2 -nr venu.txt >> answer.txt
#cat venu.txt
rm venu.txt
for ((i=0;i<count1;i++))
do
	echo $(basename ${array1[$i]}) `(find "${array1[$i]}" -printf "%s")` >> venu.txt
done
echo >> answer.txt
echo Files: >> answer.txt
sort -k 2 -nr venu.txt >> files.txt 
#awk '{ print $1 }' files.txt >> answer.txt
cat files.txt >> answer.txt
clear
cat answer.txt
rm venu.txt
rm files.txt
rm answer.txt

#echo Directories: 
#for((i=1;i<count;i++))
#do
#	echo $(basename ${array[$i]}) ,`(find "${array[$i]}" -type f | wc -l)` "file(s)" 
#done
#echo files:
#for((i=0;i<count1;i++))
#do
#	echo $(basename ${array1[$i]}) `(find "${array1[$i]}" -printf "%s")` "size"
#done

