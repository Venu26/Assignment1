#!/bin/bash
#declare -A array
#declare -i count=3
if [ ! -f "contacts.csv" ] 
then echo "fname,lastname,mobile,Office" >> contacts.csv 
fi
declare fname
declare ufname
declare lname 
declare cname
declare cnum
declare var1
if test "$1" == "-C"
then x=$2
fi 
if test "$2" == "-C" 
then x=$3
fi
if test "$3" == "-C"
then x=$4
fi 
if test "$4" == "-C"
then x=$5
fi 
if test "$5" == "-C"
then x=$6
fi 
if test "$6" == "-C"
then x=$7
fi
if test "$7" == "-C"
then x=$8
fi 
if test "$8" == "-C"
then x=$9
fi 
if test "$9" == "-C"
then x=${10}
fi 
if test "${10}" == "-C"
then x=${11}
if test "${11}" == "-C"
then x=${12}
fi 
fi
if test $x = "insert"
then  
	if test "$1" == "-f"
	then fname=$4
	fi
	if test "$1" == "-l"
	then lname=$2
	fi
	if test "$1" == "-n"
	then cnum=$2
	fi
	if test "$1" == "-o"
	then cname=$2
	fi	
	if test "$3" == "-f"
	then 
	fname=$4
	fi
	if test "$3" == "-l"
	then lname=$4
	fi
	if test "$3" == "-n"
	then cnum=$4
	fi
	if test "$3" == "-o"
	then cname=$4
	fi
	if test "$5" == "-f"
	then fname=$6
	fi
	if test "$5" == "-l"
	then lname=$6
	fi
	if test "$5" == "-n"
	then cnum=$6
	fi
	if test "$5" == "-o"
	then cname=$6
	fi
	if test "$7" == "-f"
	then fname=$8
	fi
	if test "$7" == "-l"
	then lname=$8
	fi
	if test "$7" == "-n"
	then cnum=$8
	fi
	if test "$7" == "-o"
	then cname=$8
	fi
	if test "$9" == "-f"
	then fname=${10}
	fi
	if test "$9" == "-l"
	then lname=${10}
	fi
	if test "$9" == "-n"
	then cnum=${10}
	fi
	if test "$9" == "-o"
	then cname=${10}
	fi
	echo "$fname","$lname","$cnum","$cname" >> contacts.csv
fi
if test $x == "edit"
then
	if test "$1" == "-k"
	then fname="$2"
	fi
	if test "$1" == "-f"
	then ufname="$2"
	fi
	if test "$1" == "-l"
	then lname="$2"
	fi
	if test "$1" == "-n"
	then cnum="$2"
	fi
	if test "$1" == "-o"
	then cname="$2"
	fi
	if test "$3" == "-k"
	then fname="$4"
	fi
	if test "$3" == "-f"
	then ufname="$4"
	fi
	if test "$3" == "-l"
	then lname="$4"
	fi
	if test "$3" == "-n"
	then cnum="$4"
	fi
	if test "$3" == "-o"
	then cname="$4"
	fi
	if test "$5" == "-k"
	then fname="$6"
	fi
	if test "$5" == "-f"
	then ufname="$6"
	fi
	if test "$5" == "-l"
	then lname="$6"
	fi
	if test "$5" == "-n"
	then cnum="$6"
	fi
	if test "$5" == "-o"
	then cname="$6"
	fi  
	if test "$7" == "-k"
	then fname="$8"
	fi
	if test "$7" == "-f"
	then ufname="$8"
	fi
	if test "$7" == "-l"
	then lname="$8"
	fi
	if test "$7" == "-n"
	then cnum="$8"
	fi
	if test "$7" == "-o"
	then cname="$8"
	fi
	if test "$9" == "-k"
	then fname="${10}"
	fi
	if test "$9" == "-f"
	then ufname="${10}"
	fi
	if test "$9" == "-l"
	then lname="${10}"
	fi
	if test "$9" == "-n"
	then cnum="${10}"
	fi
	if test "$9" == "-o"
	then cname="${10}"
	fi
	if test "${11}" == "-k"
	then fname="${12}"
	fi
	if test "${11}" == "-f"
	then ufname="${12}"
	fi
	if test "${11}" == "-l"
	then lname="${12}"
	fi
	if test "${11}" == "-n"
	then cnum="${12}"
	fi
	if test "${11}" == "-o"
	then cname="${12}"
	fi
	sed "s/^$fname.*/$ufname,$lname,$cnum,$cname/g" contacts.csv > input.txt
        cat input.txt > contacts.csv
	rm input.txt	
fi
if test $x == "display"
then 
if test "$1" == "-a"
then 
sort -k 1 contacts.csv
fi
if test "$1" == "-d"
then sort -k 1 -r contacts.csv
#cat contact.csv
fi 
else 
if test "$2" == "-a"
then sort -k 1 contacts.csv
fi
if test "$2" == "-d"
then sort -k 1 -r contacts.csv
fi
fi
if test "$x" == "search"
then 
	if test "$1" == "-c"
	then p="$2"
	fi
	if test "$1" == "-v" 
	then var1=$(echo $2 | cut -f2 -d,)
	fi
	if test "$3" == "-c"
	then 
		p="$4"
		#echo $x
	fi
	if test "$5" == "-v"
	then var1=$(echo $6 | cut -f2 -d,)
	fi
	if test "$5" == "-c"
	then 
		p="$6"
		#echo $x
	fi
	if test "$3" == "-v"
	then var1=$(echo $4 | cut -f2 -d,)
	fi
	#echo $p
	if test $p = "fname"
	then 
		#awk '{ if($1== "$var1") print $0;}' contacts.csv
		awk -F, -vsearch="$var1" '$1 == search' contacts.csv	
	fi
	if test $p = "lname"
	then 
		awk -F, -vsearch="$var1" '$2 == search' contacts.csv	
	fi
	if test $p = "mobile"
	then 
		awk -F, -vsearch="$var1" '$3 == search' contacts.csv	
	fi
	if test $p = "Office"
	then 
		awk -F, -vsearch="$var1" '$4 == search' contacts.csv	
	fi
fi
if test "$2" == "delete"
then 
	if test "$1" == "-c"
	then let p="$2"
	fi
	if test "$1" == "-v"
	then var1=$(echo $2 | cut -f2 -d,)
	fi
	if test "$3" == "-c"
	then let p="$4"
	fi
	if test "$5" == "-v"
	then var1=$(echo $6 | cut -f2 -d,)
	fi
	if test "$3" == "-v"
	then var1=$(echo $4 | cut -f -d,)
	fi
	if test "$5" == "-c"
	then let p="$6"
	fi
	if test $p = "fname"
	then 
		awk -F, -v var2="$var1" '$1 !=var2' contacts.csv > input.txt
		cat input.txt > contacts.scv
		rm input.txt
	fi
	if test $p = "lname"
	then 
		awk -F, -v var2="$var1" '$2 !=var2' contacts.csv > input.txt
		cat input.txt > contacts.scv
		rm input.txt
		
	fi
	if test $p = "mobile"
	then 
		awk -F, -v var2="$var1" '$3 !=var2' contacts.csv > input.txt
		cat input.txt > contacts.scv
		rm input.txt
		
	fi
	if test $p = "Office"
	then 
		awk -F, -v var2="$var1" '$4 !=var2' contacts.csv > input.txt
		cat input.txt > contacts.scv
		rm input.txt
	fi
fi
